"""تشغيل ثِق في الطرفية: python main.py"""
import sys

from thiq import ThiqBrain, ThiqError, create_provider, load_settings
from thiq.config import ConfigError

HELP = "الأوامر: /mode <general|coder|teacher|tutor|daily> | /reset | /exit"


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    try:
        settings = load_settings()
        brain = ThiqBrain(create_provider(settings), settings)
    except (ConfigError, ValueError) as e:
        print(f"خطأ في الإعدادات: {e}")
        return

    print(f"ثِق جاهز ✅ (النموذج: {settings.model}, الوضع: {brain.mode})")
    print(HELP)

    while True:
        try:
            text = input("\nأنت: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nمع السلامة!")
            return
        if not text:
            continue
        if text == "/exit":
            print("مع السلامة!")
            return
        if text == "/reset":
            brain.reset()
            print("ثِق: مسحت ذاكرة المحادثة.")
            continue
        if text.startswith("/mode"):
            parts = text.split()
            if len(parts) != 2:
                print(HELP)
                continue
            try:
                brain.set_mode(parts[1])
                print(f"ثِق: تم تغيير الوضع إلى {parts[1]}")
            except ValueError as e:
                print(e)
            continue

        try:
            print(f"\nثِق: {brain.ask(text)}")
        except ThiqError as e:
            print(f"\n⚠️ {e}")


if __name__ == "__main__":
    main()
