"""
خادم ثِق للويب — يخدم الواجهة ويربطها بنواة الذكاء الاصطناعي.
تشغيل محلي:  uvicorn server:app --host 0.0.0.0 --port 8000
على Render:  يستخدم PORT تلقائيًا من البيئة.
"""
from __future__ import annotations

import os
import threading
import time
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from thiq import ThiqBrain, ThiqError, create_provider, load_settings
from thiq.config import ConfigError
from thiq.prompts import MODES

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
INDEX_FILE = STATIC_DIR / "index.html"

# -------- إعدادات عامة --------
SESSION_TTL_SEC = int(os.getenv("THIQ_SESSION_TTL", "3600"))  # ساعة
MAX_SESSIONS = int(os.getenv("THIQ_MAX_SESSIONS", "500"))

app = FastAPI(title="THIQ AI", docs_url=None, redoc_url=None)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------- جلسات المحادثة (في الذاكرة) --------
_lock = threading.Lock()
_sessions: dict[str, dict[str, Any]] = {}
_settings = None
_provider = None
_boot_error: str | None = None


def _boot() -> None:
    global _settings, _provider, _boot_error
    try:
        _settings = load_settings()
        _provider = create_provider(_settings)
        _boot_error = None
    except (ConfigError, ValueError) as e:
        _settings = None
        _provider = None
        _boot_error = str(e)


_boot()


def _purge_old_sessions() -> None:
    now = time.time()
    dead = [sid for sid, meta in _sessions.items() if now - meta["last"] > SESSION_TTL_SEC]
    for sid in dead:
        del _sessions[sid]
    # حد أقصى للجلسات
    if len(_sessions) > MAX_SESSIONS:
        ordered = sorted(_sessions.items(), key=lambda x: x[1]["last"])
        for sid, _ in ordered[: len(_sessions) - MAX_SESSIONS]:
            del _sessions[sid]


def _get_brain(session_id: str, mode: str) -> ThiqBrain:
    if _settings is None or _provider is None:
        raise ConfigError(_boot_error or "الإعدادات غير جاهزة")
    with _lock:
        _purge_old_sessions()
        meta = _sessions.get(session_id)
        if meta is None:
            brain = ThiqBrain(_provider, _settings)
            if mode in MODES:
                brain.set_mode(mode)
            _sessions[session_id] = {"brain": brain, "last": time.time()}
            return brain
        meta["last"] = time.time()
        brain: ThiqBrain = meta["brain"]
        if mode in MODES and brain.mode != mode:
            brain.set_mode(mode)
        return brain


# -------- نماذج الطلب/الرد --------
class ChatRequest(BaseModel):
    session_id: str = Field(..., min_length=1, max_length=128)
    mode: str = "general"
    message: str = Field(..., min_length=1, max_length=8000)
    use_search: bool = False
    attachments: list[dict] = Field(default_factory=list)


class ChatResponse(BaseModel):
    reply: str


# -------- مسارات API --------
@app.get("/health")
def health():
    ok = _boot_error is None
    return {
        "status": "ok" if ok else "error",
        "provider": (_settings.provider_name if _settings else None),
        "model": (_settings.model if _settings else None),
        "error": _boot_error,
    }


@app.post("/chat")
def chat(body: ChatRequest):
    if _boot_error:
        raise HTTPException(status_code=503, detail=_boot_error)

    mode = body.mode if body.mode in MODES else "general"
    text = body.message.strip()
    if not text:
        raise HTTPException(status_code=400, detail="الرسالة فارغة")

    # المرفقات: الواجهة ترسل بيانات وصفية فقط — نذكرها في السياق إن وُجدت
    if body.attachments:
        names = ", ".join(
            str(a.get("name", "?")) for a in body.attachments[:10] if isinstance(a, dict)
        )
        if names:
            text = f"{text}\n\n[مرفقات مذكورة: {names}]"

    try:
        brain = _get_brain(body.session_id, mode)
        reply = brain.ask(text)
        return ChatResponse(reply=reply)
    except ThiqError as e:
        # أخطاء معروفة من المزوّد — نُرجعها برسالة واضحة
        raise HTTPException(status_code=502, detail=str(e))
    except ConfigError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception:
        raise HTTPException(status_code=500, detail="خطأ داخلي غير متوقع. حاول لاحقًا.")


@app.exception_handler(HTTPException)
async def http_exc_handler(request: Request, exc: HTTPException):
    # الواجهة تعتمد على res.ok؛ نُبقي التفاصيل في JSON للتشخيص
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail, "reply": None})


# -------- الواجهة الثابتة --------
if INDEX_FILE.is_file():
    @app.get("/")
    def index():
        return FileResponse(INDEX_FILE)

    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
else:
    @app.get("/")
    def index_missing():
        return JSONResponse(
            status_code=404,
            content={"detail": "ملف الواجهة static/index.html غير موجود"},
        )


if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("server:app", host="0.0.0.0", port=port, reload=False)
