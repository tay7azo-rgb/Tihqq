# ثِق (THIQ AI)

واجهة ويب + نواة ذكاء اصطناعي بـ Python.

## التشغيل المحلي

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# ضع GEMINI_API_KEY في .env
uvicorn server:app --host 0.0.0.0 --port 8000
```

افتح: http://localhost:8000

## النشر على Render

1. أنشئ **Web Service** واربط المستودع.
2. **Build Command:** `pip install -r requirements.txt`
3. **Start Command:** `uvicorn server:app --host 0.0.0.0 --port $PORT`
4. في **Environment** أضف:
   - `GEMINI_API_KEY` = مفتاحك من Google AI Studio
5. (اختياري) `THIQ_MODEL=gemini-2.0-flash`

## المزوّد

- إذا وُجد `GEMINI_API_KEY` → Google Gemini (واجهة OpenAI-compatible).
- وإلا إذا وُجد `THIQ_API_KEY` → أي خدمة متوافقة مع OpenAI (مثل Groq).

لا تضع المفتاح داخل الكود أو الواجهة.
