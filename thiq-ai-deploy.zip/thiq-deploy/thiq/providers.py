"""مزوّد النموذج. أي خدمة متوافقة مع OpenAI تشتغل بتغيير العنوان والنموذج في .env."""
from abc import ABC, abstractmethod

from openai import (
    APIConnectionError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    NotFoundError,
    OpenAI,
    PermissionDeniedError,
    RateLimitError,
)

from .config import Settings


class ThiqError(Exception):
    """خطأ مفهوم برسالة عربية واضحة للمستخدم."""


class LLMProvider(ABC):
    @abstractmethod
    def chat(self, messages: list[dict]) -> str:
        """يستقبل قائمة رسائل ويرجع نص الرد."""


class OpenAICompatibleProvider(LLMProvider):
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = OpenAI(
            api_key=settings.api_key,
            base_url=settings.base_url,
            timeout=settings.timeout,
            max_retries=2,
        )

    def chat(self, messages: list[dict]) -> str:
        s = self.settings
        try:
            response = self.client.chat.completions.create(
                model=s.model,
                messages=messages,
                temperature=s.temperature,
                max_tokens=s.max_tokens,
            )
        except AuthenticationError:
            key_hint = "GEMINI_API_KEY" if s.provider_name == "gemini" else "THIQ_API_KEY"
            raise ThiqError(f"مفتاح API غير صحيح. تأكد من {key_hint} في متغيرات البيئة.")
        except PermissionDeniedError:
            raise ThiqError("المفتاح ما عنده صلاحية لهذا النموذج أو الخدمة.")
        except NotFoundError:
            raise ThiqError(
                f"النموذج '{s.model}' أو العنوان غير موجود. راجع THIQ_MODEL و THIQ_BASE_URL."
            )
        except RateLimitError:
            raise ThiqError("وصلت حد الاستخدام. انتظر دقيقة وحاول مرة ثانية.")
        except APITimeoutError:
            raise ThiqError("انتهت مهلة الاتصال. حاول مرة ثانية.")
        except APIConnectionError:
            raise ThiqError("تعذّر الاتصال بالخدمة. تأكد من الإنترنت ومن THIQ_BASE_URL.")
        except APIStatusError as e:
            raise ThiqError(f"الخدمة رجّعت خطأ ({e.status_code}). حاول لاحقًا.")

        text = response.choices[0].message.content if response.choices else None
        if not text or not text.strip():
            raise ThiqError("وصل رد فارغ من النموذج. حاول مرة ثانية.")
        return text.strip()


def create_provider(settings: Settings) -> LLMProvider:
    return OpenAICompatibleProvider(settings)
