"""ذاكرة المحادثة الحالية (في الذاكرة فقط، تنتهي بإغلاق البرنامج)."""


class ConversationMemory:
    def __init__(self, max_messages: int = 20):
        self.max_messages = max_messages
        self._messages: list[dict] = []

    def add(self, role: str, content: str) -> None:
        self._messages.append({"role": role, "content": content})
        # نحتفظ بآخر الرسائل فقط حتى لا يكبر الطلب ويزيد الاستهلاك
        if len(self._messages) > self.max_messages:
            self._messages = self._messages[-self.max_messages:]

    def pop_last(self) -> None:
        if self._messages:
            self._messages.pop()

    def get(self) -> list[dict]:
        return list(self._messages)

    def clear(self) -> None:
        self._messages.clear()
