"""عقل ثِق: يجمع الشخصية والذاكرة والمزوّد."""
from .config import Settings
from .memory import ConversationMemory
from .prompts import MODES, build_system_prompt
from .providers import LLMProvider


class ThiqBrain:
    def __init__(self, provider: LLMProvider, settings: Settings):
        self.provider = provider
        self.memory = ConversationMemory(settings.max_history)
        self.mode = settings.default_mode
        build_system_prompt(self.mode)  # يتأكد أن الوضع صحيح

    def set_mode(self, mode: str) -> None:
        build_system_prompt(mode)  # يرفع خطأ إذا الوضع غير معروف
        self.mode = mode

    @staticmethod
    def modes() -> list[str]:
        return list(MODES)

    def reset(self) -> None:
        self.memory.clear()

    def ask(self, user_text: str) -> str:
        self.memory.add("user", user_text)
        messages = [{"role": "system", "content": build_system_prompt(self.mode)}]
        messages += self.memory.get()
        try:
            answer = self.provider.chat(messages)
        except Exception:
            self.memory.pop_last()  # لا نحفظ سؤالًا فشل جوابه
            raise
        self.memory.add("assistant", answer)
        return answer
