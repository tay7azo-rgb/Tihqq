"""قراءة الإعدادات من ملف .env أو متغيرات البيئة."""
import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")


class ConfigError(Exception):
    pass


# إعدادات افتراضية لـ Google Gemini (واجهة متوافقة مع OpenAI)
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"
GEMINI_DEFAULT_MODEL = "gemini-2.0-flash"


@dataclass(frozen=True)
class Settings:
    api_key: str
    base_url: str
    model: str
    temperature: float
    max_tokens: int
    timeout: float
    max_history: int
    default_mode: str
    provider_name: str  # "gemini" | "openai_compatible"


def load_settings() -> Settings:
    """
    الأولوية:
      1) GEMINI_API_KEY  → مزوّد Google Gemini
      2) THIQ_API_KEY    → أي خدمة متوافقة مع OpenAI (مثل Groq)
    لا يُوضع المفتاح داخل الكود أبدًا.
    """
    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
    thiq_key = os.getenv("THIQ_API_KEY", "").strip()

    if gemini_key:
        api_key = gemini_key
        base_url = os.getenv("THIQ_BASE_URL", GEMINI_BASE_URL).strip()
        model = os.getenv("THIQ_MODEL", GEMINI_DEFAULT_MODEL).strip()
        provider_name = "gemini"
    elif thiq_key:
        api_key = thiq_key
        base_url = os.getenv("THIQ_BASE_URL", "https://api.groq.com/openai/v1").strip()
        model = os.getenv("THIQ_MODEL", "llama-3.3-70b-versatile").strip()
        provider_name = "openai_compatible"
    else:
        raise ConfigError(
            "ما لقيت مفتاح API. ضع GEMINI_API_KEY (مفضّل) أو THIQ_API_KEY "
            "في متغيرات البيئة أو في ملف .env"
        )

    try:
        return Settings(
            api_key=api_key,
            base_url=base_url,
            model=model,
            temperature=float(os.getenv("THIQ_TEMPERATURE", "0.5")),
            max_tokens=int(os.getenv("THIQ_MAX_TOKENS", "1024")),
            timeout=float(os.getenv("THIQ_TIMEOUT", "30")),
            max_history=int(os.getenv("THIQ_MAX_HISTORY", "20")),
            default_mode=os.getenv("THIQ_DEFAULT_MODE", "general").strip(),
            provider_name=provider_name,
        )
    except ValueError as e:
        raise ConfigError(f"قيمة رقمية غلط في الإعدادات: {e}")
