# ثِق (THIQ AI)

واجهة ويب + نواة ذكاء اصطناعي بـ Python.

## هيكل المشروع (جذر المستودع)

```
requirements.txt   ← يجب أن يكون هنا (جذر المشروع)
server.py          ← تطبيق FastAPI (المتغير: app)
main.py            ← تشغيل الطرفية اختياري
render.yaml
static/index.html
thiq/              ← نواة الذكاء الاصطناعي
```

## التشغيل المحلي

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# ضع GEMINI_API_KEY في .env
uvicorn server:app --host 0.0.0.0 --port 8000
```

## النشر على Render

1. ارفع **محتويات** هذا المجلد إلى جذر المستودع على GitHub (وليس مجلدًا داخليًا).
2. أنشئ **Web Service**.
3. **Root Directory:** اتركه فارغًا (`.` / الجذر) — إلا إذا رفعت الملفات داخل مجلد فرعي فضع اسم ذلك المجلد.
4. **Build Command:**
   ```
   pip install -r requirements.txt
   ```
5. **Start Command:**
   ```
   uvicorn server:app --host 0.0.0.0 --port $PORT
   ```
6. في **Environment** أضف:
   - `GEMINI_API_KEY` = مفتاحك من Google AI Studio

لا تضع المفتاح داخل الملفات.
